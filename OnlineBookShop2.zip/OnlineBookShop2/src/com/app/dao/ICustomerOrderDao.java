package com.app.dao;

import com.app.pojos.*;

public interface ICustomerOrderDao {

	public void addCustomerOrder(CustomerOrder customerOrder);
	
}

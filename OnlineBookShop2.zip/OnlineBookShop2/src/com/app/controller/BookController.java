package com.app.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Book;
import com.app.service.IBookService;

@Controller
@RequestMapping("/book")
public class BookController {
	
	@Autowired
	IBookService bookService;
	
	@GetMapping("/viewbook")
	public String ShowBook(@RequestParam int bookId,Model map)
	{
		map.addAttribute("book", bookService.getBookById(bookId));
		System.out.println(bookService.getBookById(bookId));
		return "/customer/viewbook";
	}

}

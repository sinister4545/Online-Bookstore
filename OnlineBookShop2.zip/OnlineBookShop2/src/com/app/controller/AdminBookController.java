package com.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Book;
import com.app.service.IBookService;

@Controller
@RequestMapping("/admin")
public class AdminBookController {

	@Autowired
	private IBookService bookService; 
	@GetMapping("/delete")
	public String deleteBook(@RequestParam int bookId,
			RedirectAttributes flashMap) {
		System.out.println("in delete book "+bookId+" "+flashMap);
		flashMap.addFlashAttribute("status",bookService.deleteBook(bookId));
			return "redirect:/admin/booklist"; //redirect view name
	}
	@GetMapping("/addbook")
	public String showAddBook(Book book)
	{
		
		return "/admin/addbook";
	}
	@PostMapping("/addbook")
	public String addBook(Book book,Model map)
	{
		System.out.println("in Add Book");
		map.addAttribute("bookStatus",bookService.addBook(book));
		
		return "redirect:/admin/booklist";
	}
	@GetMapping("/update")
	public String showUpdateForm(@RequestParam int bookId,Model map)
	{
		System.out.println("in show update form ");
		map.addAttribute("book",bookService.getBookById(bookId));
		return "/admin/updatebook";
	}
	
	@PostMapping("/update")
	public String processUpdateForm(Book book,RedirectAttributes flashMap)
	{
		System.out.println("in process update "+book);
		flashMap.addFlashAttribute("status",bookService.editBook(book));
		return "redirect:/admin/booklist";
	}
	
}

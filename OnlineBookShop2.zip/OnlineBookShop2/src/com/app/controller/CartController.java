package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.service.ICartService;

@Controller
@RequestMapping("/customer")
public class CartController {
	@Autowired
	private ICartService cartService;
	
	@GetMapping("/cart")
	public String getCart() {
		int cartId = 1;
		return "/customer/cart";
	}

}

package com.app.service;

import java.util.List;

import com.app.pojos.*;

public interface IBookService {

	List<Book> getBookList();
	
	Book getBookById(int id);
	
	public String addBook(Book book);
	
	public String editBook(Book book);
	
	public String deleteBook(int bid);
}

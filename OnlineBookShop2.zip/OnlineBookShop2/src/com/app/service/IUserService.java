package com.app.service;

import com.app.pojos.*;

public interface IUserService {

	Users validateUser(String user,String pass);

}
